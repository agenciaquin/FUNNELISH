import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { tenantActual } from '@/lib/tenant';
import { createServerSupabaseClient } from '@/lib/supabase';
import { chat } from '@/lib/quinchat/claude';
import { bloqueAprendido } from '@/lib/quino-aprendizaje';
import { guiaSeccion, esTemaConexion } from '@/lib/quino-secciones';

export const dynamic = 'force-dynamic';

/**
 * Asistente de conexión (GRATIS para el cliente).
 * Un ayudante entrenado SOLO para guiar a conectar WhatsApp con Meta.
 * Corre en el servidor con la llave de la agencia (ANTHROPIC_API_KEY),
 * así que al cliente no le cuesta nada. Modelo Haiku = centavos por charla.
 *
 * POST { messages: [{role:'user'|'assistant', content}] } -> { reply }
 */

// Conocimiento del asistente = resumen del manual paso a paso.
const CONOCIMIENTO = `
DATOS QUE EL CLIENTE DEBE CONSEGUIR EN META (y pegar en Ajustes → Conexión WhatsApp):
1. Access Token (permanente): la "llave" del bot. Se crea con un USUARIO DEL SISTEMA en Configuración del negocio → Usuarios del sistema. Vencimiento "Nunca". Permisos: whatsapp_business_messaging, whatsapp_business_management, business_management. Empieza por "EAA...". El token de la barra de API dura solo 24 h: NO sirve.
2. Phone Number ID (principal): NO es el número visible; es un ID numérico que sale en WhatsApp → Configuración de la API, debajo del número.
3. Phone Number ID (ventas): opcional, solo si usa un segundo número.
4. Verify Token: una palabra secreta que el cliente INVENTA. Debe ser IDÉNTICA en Meta (al configurar el webhook) y en el panel.
5. WABA ID (opcional): ID de la cuenta de WhatsApp Business (WhatsApp → Configuración de la API).
6. App ID (opcional): número de la app, arriba en el panel de la app en developers.facebook.com.

PASOS (orden):
1) Crear Portafolio de Negocio en business.facebook.com (Configuración del negocio).
2) Crear la App en developers.facebook.com/apps → caso de uso "Conectar con clientes a través de WhatsApp" → da el App ID.
3) WhatsApp → Configuración de la API → elegir/crear la cuenta de WhatsApp Business (WABA) → da el WABA ID.
4) Agregar y verificar el número (SMS/llamada) → aparece el Phone Number ID.
5) Token permanente con Usuario del sistema (ver dato 1).
6) Webhook: copiar la "URL del Webhook" del panel, pegarla en Meta (WhatsApp → Configuración → Webhook → Editar), poner el mismo Verify Token, "Verificar y guardar", y SUSCRIBIRSE al campo "messages".
7) Pegar todo en el panel (Ajustes → Conexión WhatsApp) y Guardar.

ERRORES COMUNES:
- "El webhook no verifica": el Verify Token no coincide o la URL tiene un espacio. Deben ser idénticos.
- "No llegan mensajes": falta suscribirse al campo "messages", o el número está en modo prueba.
- "El token expiró a las 24h": usó un token temporal; debe usar el de Usuario del sistema (Nunca).
- "(#10)/(#200) permission denied": al usuario del sistema le faltan permisos/asignar app y WABA con control total.
- "Recipient phone number not in allowed list": número en modo prueba / negocio sin verificar.
- "El número ya tiene WhatsApp": un número no puede estar en la app de WhatsApp normal y en la API a la vez.

VERIFICACIÓN DEL NEGOCIO: en Configuración del negocio → Centro de seguridad. Sube los límites de mensajes. No es obligatoria para empezar a probar.
`.trim();

function reglas(seccion: string | null | undefined, incluirConexion: boolean): string {
  const g = guiaSeccion(seccion);
  const base = [
    'Eres "Quino", el asistente/copiloto dentro de la app QuinChat de la Agencia QUIN.',
    'Ayudas al usuario a usar la app y, sobre todo, la pantalla donde está parado ahora mismo.',
    `PANTALLA ACTUAL: ${g.titulo}. Qué se hace aquí: ${g.guia}`,
    'Prioriza ayudar con lo de la pantalla actual. Si pregunta por algo de otra sección, oriéntalo en corto y dile a qué menú/pestaña ir.',
    'Sé breve, cálido y concreto. Tutea. Usa pasos numerados cortos cuando expliques algo. Nada de tecnicismos innecesarios.',
    'No inventes botones, pasos ni URLs que no conozcas. Si no estás seguro, dilo y sugiere el manual o el botón de soporte.',
    'Nunca pidas ni muestres tokens, contraseñas ni datos sensibles.',
    'Responde SIEMPRE en español.',
  ];
  if (incluirConexion) {
    base.push('', 'GUÍA PROFUNDA PARA CONECTAR WHATSAPP CON META (úsala cuando pregunten de conexión):', CONOCIMIENTO);
  }
  return base.join('\n');
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'no autorizado' }, { status: 401 });
  const tid = await tenantActual();
  if (!tid) return NextResponse.json({ error: 'sin empresa' }, { status: 401 });

  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ error: 'JSON inválido' }, { status: 400 }); }

  const entrantes = Array.isArray(body?.messages) ? body.messages : [];
  // Anti-abuso: máximo 16 turnos, cada mensaje máx 1500 caracteres.
  const messages = entrantes
    .filter((m: any) => (m?.role === 'user' || m?.role === 'assistant') && typeof m?.content === 'string')
    .slice(-16)
    .map((m: any) => ({ role: m.role, content: String(m.content).slice(0, 1500) }));

  if (messages.length === 0 || messages[messages.length - 1].role !== 'user') {
    return NextResponse.json({ error: 'falta el mensaje del cliente' }, { status: 400 });
  }

  // ¿En qué pantalla está parado el usuario? (para guiarlo en eso)
  const seccion = typeof body?.seccion === 'string' ? body.seccion : null;
  const ultimoTexto = messages[messages.length - 1].content;
  const incluirConexion = esTemaConexion(seccion, ultimoTexto);

  // Capturas de pantalla que adjuntó el cliente. Máx 2, solo tipos de imagen.
  const TIPOS_IMG = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
  const imagenes = (Array.isArray(body?.imagenes) ? body.imagenes : [])
    .filter((im: any) => im && typeof im.base64 === 'string' && TIPOS_IMG.includes(im.mimeType))
    .slice(0, 2)
    .map((im: any) => ({ mimeType: im.mimeType as string, base64: String(im.base64).slice(0, 7_000_000) }));

  // Contexto real del cliente (para respuestas personalizadas). Sin datos sensibles.
  let dinamico = '';
  try {
    const admin = createServerSupabaseClient();
    const { data } = await admin
      .from('tenants')
      .select('nombre, slug, wa_phone_number_id, wa_verify_token, wa_access_token')
      .eq('id', tid)
      .maybeSingle();
    if (data) {
      const origin = req.nextUrl?.origin ?? '';
      const webhook = `${origin}/api/whatsapp/webhook/${data.slug ?? ''}`;
      const pendientes: string[] = [];
      if (!data.wa_phone_number_id) pendientes.push('Phone Number ID');
      if (!data.wa_verify_token) pendientes.push('Verify Token');
      if (!data.wa_access_token) pendientes.push('Access Token');
      dinamico = [
        `DATOS REALES DE ESTE CLIENTE (úsalos si pregunta por lo suyo):`,
        `- Empresa: ${data.nombre ?? ''}`,
        `- Su URL de Webhook (la que debe pegar en Meta): ${webhook}`,
        `- Su Verify Token debe coincidir con el que ponga aquí en el panel.`,
        pendientes.length
          ? `- Datos que todavía le faltan por llenar en el panel: ${pendientes.join(', ')}.`
          : `- Ya tiene todos los datos principales llenos.`,
      ].join('\n');
    }
  } catch { /* si falla, el asistente sigue funcionando sin contexto */ }

  // Lo que Quino ha aprendido de casos reales con otros clientes (cerebro compartido).
  let aprendido = '';
  try { aprendido = await bloqueAprendido(40); } catch { /* opcional */ }

  const systemDynamic = [dinamico, aprendido].filter(Boolean).join('\n\n');

  try {
    const resp = await chat({
      messages,
      tenantId: tid,
      systemPrompt: reglas(seccion, incluirConexion),
      systemDynamic: systemDynamic || undefined,
      maxTokens: 600,
      imagenes: imagenes.length ? imagenes : undefined,
    });
    return NextResponse.json({ reply: resp.message });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? 'Error del asistente' }, { status: 500 });
  }
}
