import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabaseClient } from '@/lib/supabase';
import { tenantActual } from '@/lib/tenant';

/** Lista los embudos del cliente para el panel. */
export async function GET() {
  const tid = await tenantActual();
  if (!tid) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const supabase = createServerSupabaseClient();
  const { data, error } = await supabase
    .from('funnels').select('*').eq('tenant_id', tid).order('creado_at', { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ embudos: data ?? [] });
}

/** Crea o actualiza un embudo. */
export async function POST(req: NextRequest) {
  try {
    const tid = await tenantActual();
    if (!tid) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

    const b = await req.json();

    if (!b?.slug?.trim() || !b?.producto?.trim()) {
      return NextResponse.json({ error: 'Falta la dirección o el nombre del producto.' }, { status: 400 });
    }

    // La dirección va en la URL: sin tildes, espacios ni mayúsculas
    const slug = String(b.slug).toLowerCase()
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');

    const fila = {
      slug,
      tenant_id:         tid,
      activo:            b.activo !== false,
      nombre:            String(b.nombre ?? b.producto).trim(),
      titulo:            String(b.titulo ?? '').trim(),
      producto:          String(b.producto).trim(),
      precio:            Number(b.precio ?? 0),
      precio_antes:      b.precio_antes ? Number(b.precio_antes) : null,
      imagenes:          Array.isArray(b.imagenes) ? b.imagenes : [],
      imagen_banner:     b.imagen_banner   || null,
      imagen_clientes:   b.imagen_clientes || null,
      imagen_detalle:    b.imagen_detalle  || null,
      caracteristicas:   Array.isArray(b.caracteristicas) ? b.caracteristicas : [],
      frases:            Array.isArray(b.frases) ? b.frases.slice(0, 5) : [],
      tallas:            Array.isArray(b.tallas) ? b.tallas : [],
      variantes:         Array.isArray(b.variantes) ? b.variantes : [],
      horas_contador:    Number(b.horas_contador ?? 10),
      personas_comprando: Number(b.personas_comprando ?? 27),
      whatsapp:           String(b.whatsapp ?? '').replace(/\D/g, ''),
      // Se limpian espacios: un ID o token con espacios rompe la llamada a Meta
      pixel_meta:         String(b.pixel_meta         ?? '').trim() || null,
      pixel_meta_token:   String(b.pixel_meta_token   ?? '').trim() || null,
      pixel_tiktok:       String(b.pixel_tiktok       ?? '').trim() || null,
      pixel_tiktok_token: String(b.pixel_tiktok_token ?? '').trim() || null,
      audio_url:          b.audio_url          || null,
      video_url:          b.video_url          || null,
      color:              b.color              || null,
      miniatura_url:      b.miniatura_url      || null,
      anuncios:           String(b.anuncios ?? '').trim() || null,
      bloques:            Array.isArray(b.bloques) ? b.bloques : [],
    };

    const supabase = createServerSupabaseClient();
    // El slug es único GLOBAL: si ya existe y es de OTRO cliente, se rechaza.
    const { data: existe } = await supabase
      .from('funnels').select('id, tenant_id').eq('slug', slug).maybeSingle();
    if (existe && existe.tenant_id && existe.tenant_id !== tid) {
      return NextResponse.json({ error: 'Esa dirección (slug) ya está en uso por otra empresa. Elige otra.' }, { status: 409 });
    }

    let { error } = existe?.id
      ? await supabase.from('funnels').update(fila).eq('id', existe.id).eq('tenant_id', tid)
      : await supabase.from('funnels').insert(fila);

    // Si la base todavía no tiene alguna columna nueva (tokens o audio), se guarda
    // sin ella en vez de perder todo el embudo, y se avisa qué falta.
    if (error && /column .*(pixel_meta_token|pixel_tiktok_token|audio_url|video_url|color|miniatura_url|anuncios|bloques).* does not exist/i.test(error.message)) {
      const { pixel_meta_token, pixel_tiktok_token, audio_url, video_url, color, miniatura_url, anuncios, bloques, ...sinNuevas } = fila;
      const reintento = existe?.id
        ? await supabase.from('funnels').update(sinNuevas).eq('id', existe.id).eq('tenant_id', tid)
        : await supabase.from('funnels').insert(sinNuevas);
      if (reintento.error) return NextResponse.json({ error: reintento.error.message }, { status: 500 });

      return NextResponse.json({
        ok: true, slug,
        aviso: 'Se guardó, pero falta agregar en la base de datos las columnas nuevas (tokens / audio).',
      });
    }

    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ ok: true, slug });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? 'Error inesperado.' }, { status: 500 });
  }
}

/** Elimina un embudo. */
export async function DELETE(req: NextRequest) {
  const tid = await tenantActual();
  if (!tid) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });

  const slug = req.nextUrl.searchParams.get('slug');
  if (!slug) return NextResponse.json({ error: 'Falta la dirección.' }, { status: 400 });

  const supabase = createServerSupabaseClient();
  const { error } = await supabase.from('funnels').delete().eq('slug', slug).eq('tenant_id', tid);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
