'use client';

import { useState } from 'react';
import Image from 'next/image';
import { signOut } from 'next-auth/react';
import BotonAvisos from './BotonAvisos';

export type PanelSection = 'chat' | 'chat_ventas' | 'estadisticas' | 'embudos' | 'pedidos' | 'ventas' | 'vendedores' | 'seguimiento' | 'objeciones' | 'memoria' | 'faq' | 'entrenamiento' | 'plantillas' | 'disparadores' | 'contactos' | 'etiquetas' | 'catalogos' | 'integraciones' | 'ajustes' | 'manual' | 'wa_config' | 'empresas' | 'plantillas_embudo' | 'quino_aprendizaje' | 'recarga';

// Íconos SVG personalizados (embudo de ventas y WhatsApp)
const IconoEmbudo = ({ color }: { color: string }) => (
  <svg viewBox="0 0 24 24" fill={color} width="18" height="18" aria-hidden>
    <path d="M3 4h18a1 1 0 0 1 .8 1.6L15 14v5a1 1 0 0 1-.55.9l-3 1.5A1 1 0 0 1 10 21.5V14L2.2 5.6A1 1 0 0 1 3 4z" />
  </svg>
);
const IconoWhatsApp = ({ color }: { color: string }) => (
  <svg viewBox="0 0 24 24" fill={color} width="18" height="18" aria-hidden>
    <path d="M12 2C6.48 2 2 6.48 2 12c0 1.77.46 3.42 1.27 4.86L2 22l5.25-1.38A9.94 9.94 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm0 18c-1.58 0-3.05-.46-4.29-1.25l-.3-.18-3.12.82.83-3.04-.2-.31A7.93 7.93 0 0 1 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8zm4.5-5.6c-.25-.12-1.47-.72-1.7-.8-.23-.09-.4-.13-.56.12-.17.25-.64.8-.79.97-.14.16-.29.18-.54.06-.25-.13-1.05-.39-2-1.23-.74-.66-1.24-1.48-1.38-1.73-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.44.12-.15.16-.25.25-.42.08-.17.04-.31-.02-.44-.06-.12-.56-1.35-.77-1.85-.2-.48-.4-.42-.56-.42l-.48-.01c-.16 0-.42.06-.64.31-.22.25-.85.83-.85 2.02s.87 2.35 1 2.51c.12.17 1.7 2.6 4.13 3.65.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.44-.59 1.64-1.16.2-.57.2-1.06.14-1.16-.06-.1-.22-.16-.47-.28z" />
  </svg>
);

// ── Estructura de menú: 6 grupos, cada uno con sus pestañas (estilo Funnelish) ──
export type Tab = { key: PanelSection; label: string };
export type Grupo = { key: string; label: string; icon?: string; svg?: 'embudo' | 'whatsapp'; color?: string; soloAdmin?: boolean; tabs: Tab[] };

export const GRUPOS: Grupo[] = [
  { key: 'empresas', label: 'Empresas', icon: '🏢', soloAdmin: true, tabs: [
    { key: 'empresas',          label: 'Empresas' },
    { key: 'quino_aprendizaje', label: 'Aprendizaje Quino' },
  ] },
  { key: 'chats', label: 'Chats', svg: 'whatsapp', color: '#25D366', tabs: [
    { key: 'chat',        label: 'Chat Funnel' },
    { key: 'chat_ventas', label: 'Chat WhatsApp' },
  ] },
  { key: 'embudos', label: 'Embudos', svg: 'embudo', color: '#ffffff', tabs: [
    { key: 'plantillas_embudo', label: 'Plantillas' },
    { key: 'embudos',           label: 'Embudos' },
    { key: 'pedidos',           label: 'Ventas' },
    { key: 'estadisticas',      label: 'Estadísticas' },
  ] },
  { key: 'bot', label: 'Bot', icon: '🤖', tabs: [
    { key: 'entrenamiento', label: 'Entrenamiento' },
    { key: 'memoria',       label: 'Memoria' },
    { key: 'faq',           label: 'Preguntas frecuentes' },
    { key: 'objeciones',    label: 'Objeciones' },
    { key: 'disparadores',  label: 'Disparadores' },
    { key: 'catalogos',     label: 'Catálogos' },
    { key: 'plantillas',    label: 'Plantillas WhatsApp' },
  ] },
  { key: 'marketing', label: 'Marketing', icon: '🎯', tabs: [
    { key: 'seguimiento', label: 'Meta Ads' },
  ] },
  { key: 'ajustes', label: 'Ajustes', icon: '⚙️', tabs: [
    { key: 'recarga',       label: 'Recarga' },
    { key: 'wa_config',     label: 'Conexión WhatsApp' },
    { key: 'integraciones', label: 'Integraciones' },
    { key: 'contactos',     label: 'Contactos' },
    { key: 'etiquetas',     label: 'Etiquetas' },
    { key: 'vendedores',    label: 'Vendedores' },
    { key: 'ventas',        label: 'Estado en Effi' },
    { key: 'ajustes',       label: 'Ajustes' },
    { key: 'manual',        label: 'Manual' },
  ] },
];

/** Devuelve el grupo al que pertenece una sección (para pintar la pestaña activa). */
export function grupoDeSeccion(s: PanelSection): Grupo {
  return GRUPOS.find(g => g.tabs.some(t => t.key === s)) ?? GRUPOS[1];
}

interface Props {
  userName: string;
  activeSection: PanelSection;
  onSectionChange: (s: PanelSection) => void;
  esSuperAdmin?: boolean;
}

export default function Sidebar({ userName, activeSection, onSectionChange, esSuperAdmin }: Props) {
  const initial = userName.charAt(0).toUpperCase() || 'U';
  const grupoActivo = grupoDeSeccion(activeSection).key;
  const grupos = GRUPOS.filter(g => !g.soloAdmin || esSuperAdmin);
  // Grupos abiertos manualmente en el acordeón (el grupo activo siempre va abierto)
  const [abiertos, setAbiertos] = useState<string[]>([]);

  return (
    <aside className="w-[190px] h-full min-h-0 flex flex-col shrink-0 text-white bg-gradient-to-b from-[#00B5A6] via-[#00A89D] to-[#00847A] shadow-xl shadow-[#00847A]/20">

      {/* Brand — logo QuinChat */}
      <div className="px-4 py-4 border-b border-white/15 flex flex-col items-center">
        <Image
          src="/logo-quin-app.png"
          alt="QuinChat — Agencia Quin"
          width={110}
          height={110}
          className="object-contain drop-shadow-lg"
          priority
        />
        <p className="text-[10px] text-white/70 mt-2">Panel de administración</p>
      </div>

      {/* Account */}
      <div className="px-3 py-3 border-b border-white/15 flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-full bg-white/20 border border-white/40 flex items-center justify-center text-xs font-bold text-white shrink-0">
          {initial}
        </div>
        <div className="min-w-0">
          <div className="text-xs font-semibold text-white truncate">{userName || 'Agencia Quin'}</div>
          <div className="flex items-center gap-1 mt-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 shrink-0 animate-pulse" />
            <span className="text-[10px] text-white/75">Activo</span>
          </div>
        </div>
      </div>

      {/* Nav — 6 grupos en acordeón. El grupo se abre hacia abajo mostrando sus
          opciones, y arriba se mantienen las pestañas del grupo activo. */}
      <nav className="flex-1 px-2 py-3 flex flex-col gap-1 overflow-y-auto">
        {grupos.map(g => {
          const active = grupoActivo === g.key;
          const tieneSub = g.tabs.length > 1;
          const abierto = active || abiertos.includes(g.key);
          return (
            <div key={g.key} className="flex flex-col">
              <button
                onClick={() => {
                  onSectionChange(g.tabs[0].key);
                  if (tieneSub) {
                    setAbiertos(prev =>
                      prev.includes(g.key) ? prev.filter(x => x !== g.key) : [...prev, g.key]
                    );
                  }
                }}
                className={`group w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-left transition-all duration-200 ease-out ${
                  active
                    ? 'bg-white text-[#00847A] font-semibold shadow-md shadow-black/10'
                    : 'text-white/85 hover:text-white hover:bg-white/15'
                }`}
              >
                <span className="text-base shrink-0 flex items-center">
                  {g.svg === 'embudo'   ? <IconoEmbudo color={active ? '#00847A' : (g.color ?? '#ffffff')} />
                   : g.svg === 'whatsapp' ? <IconoWhatsApp color={g.color ?? '#25D366'} />
                   : g.icon}
                </span>
                <span className="truncate flex-1">{g.label}</span>
                {tieneSub && (
                  <span className={`text-xs shrink-0 transition-transform duration-200 ${abierto ? 'rotate-180' : ''} ${active ? 'text-[#00A89D]' : 'text-white/60'}`}>⌄</span>
                )}
              </button>

              {/* Subopciones desplegables (acordeón) */}
              {tieneSub && abierto && (
                <div className="mt-1 mb-1 ml-4 pl-3 flex flex-col gap-0.5 border-l border-white/20">
                  {g.tabs.map(t => {
                    const subActive = t.key === activeSection;
                    return (
                      <button
                        key={t.key}
                        onClick={() => onSectionChange(t.key)}
                        className={`w-full text-left px-3 py-1.5 rounded-lg text-[13px] transition-all duration-150 ${
                          subActive
                            ? 'bg-white/25 text-white font-semibold'
                            : 'text-white/70 hover:text-white hover:bg-white/12'
                        }`}
                      >
                        {t.label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Bottom */}
      <div className="px-2 pb-4 border-t border-white/15 pt-3 flex flex-col gap-1">
        <BotonAvisos />
        {/* Refrescar toda la app: si algo se traba, la deja como recién abierta */}
        <button
          onClick={() => window.location.reload()}
          title="Recargar la aplicación completa"
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-white/85 hover:text-white hover:bg-white/15 hover:translate-x-1 transition-all duration-200 ease-out"
        >
          <span className="text-base shrink-0">⟳</span>
          <span>Refrescar app</span>
        </button>
        <button
          onClick={() => signOut({ callbackUrl: '/login' })}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-white/85 hover:text-white hover:bg-white/15 hover:translate-x-1 transition-all duration-200 ease-out"
        >
          <span className="text-base shrink-0">↩</span>
          <span>Cerrar sesión</span>
        </button>
      </div>
    </aside>
  );
}
