// =====================================================
// Pre-filtro del bot (AHORRO DE IA).
// Antes de gastar en la IA, intentamos resolver el mensaje con REGLAS gratis:
//   #3 ignorar "ok/gracias/stickers" y despedidas (no responder de último)
//   #6 bienvenida por anuncio (catálogo + precios) al primer contacto
//      (los disparadores por palabra también se resuelven aquí)
//   #5 responder desde una Pregunta Frecuente aprobada
// Todo es FAIL-OPEN: si algo falla o no aplica, devuelve saltarIA=false y
// el bot responde con IA como siempre.
// =====================================================

import { sendTextMessage, sendImageByUrl } from '@/lib/whatsapp';

interface Cond { tipo?: string; valor?: string }
interface Acc { tipo?: string; plantilla_id?: string; valor?: string }

/** minúsculas + sin tildes, para comparar sin importar acentos/mayúsculas. */
function norm(s: string): string {
  return String(s ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
}

/** Registra en el chat lo que el bot envió por regla (para el panel, el historial
 *  y para saber que el bot ya respondió — evita repetir la bienvenida). */
async function registrar(supabase: any, from: string, content: string) {
  try {
    const now = new Date().toISOString();
    await supabase.from('messages').insert({
      id: `bot-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      conversation_id: from, content, role: 'assistant', type: 'text', created_at: now,
    });
    await supabase.from('conversations').update({
      last_message: content.slice(0, 100), last_message_time: now, unread_count: 0,
    }).eq('id', from);
  } catch { /* no bloquear */ }
}

// ── #3: mensajes que NO ameritan gastar IA ──────────────────────────────────
// Solo acuses y despedidas claros (frase completa). NO incluimos "sí/no" ni
// palabras de producto, para no callar respuestas que sí importan.
const TRIVIAL = /^(ok(is|ay|is)?|oka+y?|dale|listo|vale|bueno|perfecto|de\s*nada|graci(as|a)s?|muchas\s+gracias|gracias\s+(por\s+todo|mil)|👍|👌|🙏|🙌|😊|👏|❤️|🔥)[\s.!]*$/i;
const DESPEDIDA = /\b(chao|chaito|adi[oó]s|hasta\s+(luego|pronto|ma[ñn]ana)|nos\s+vemos|bye|me\s+despido|que\s+est[eé]s\s+bien|feliz\s+(d[ií]a|tarde|noche)|hablamos\s+(luego|despu[eé]s)|gracias\s+por\s+(todo|tu\s+ayuda))\b/i;

function esIgnorable(texto: string, tipo?: string): boolean {
  if (tipo === 'sticker' || tipo === 'reaction') return true;
  const t = texto.trim();
  if (!t) return false;
  if (TRIVIAL.test(t)) return true;                 // acuse ("gracias", "listo"…)
  if (t.length <= 60 && DESPEDIDA.test(t)) return true; // despedida
  return false;
}

// ── #6: bienvenida por anuncio ──────────────────────────────────────────────
async function bienvenidaPorAnuncio(supabase: any, from: string): Promise<boolean> {
  try {
    const { data: conv } = await supabase
      .from('conversations').select('origen_anuncio').eq('id', from).maybeSingle();
    if (!conv?.origen_anuncio) return false;

    // Solo al PRIMER contacto (el bot aún no ha respondido nada).
    const { count } = await supabase
      .from('messages').select('*', { count: 'exact', head: true })
      .eq('conversation_id', from).eq('role', 'assistant');
    if (count && count > 0) return false;

    let adId = '';
    try { adId = String(JSON.parse(String(conv.origen_anuncio))?.anuncio ?? '').trim(); } catch { adId = ''; }
    if (!adId) return false;

    const { data: cats } = await supabase
      .from('catalogos_bot')
      .select('mensaje_bienvenida, anuncios, catalogo_colores(url_imagen)')
      .eq('activo', true);
    const cat = (cats ?? []).find((c: any) =>
      String(c.anuncios ?? '').split(/[,\s]+/).map((x: string) => x.trim()).filter(Boolean).includes(adId),
    );
    if (!cat?.mensaje_bienvenida) return false;

    // Envía el mensaje con precios + las fotos del catálogo (máx 8), sin IA.
    await sendTextMessage(from, cat.mensaje_bienvenida);
    await registrar(supabase, from, cat.mensaje_bienvenida);
    const fotos = (cat.catalogo_colores ?? []).map((v: any) => v.url_imagen).filter(Boolean).slice(0, 8);
    for (const url of fotos) { await sendImageByUrl(from, url); }
    return true;
  } catch { return false; }
}

// ── Disparadores por palabra (regla → plantilla) ────────────────────────────
async function disparadoresPorPalabra(supabase: any, from: string, t: string): Promise<{ manejado: boolean; saltarIA: boolean }> {
  try {
    const { data: disps } = await supabase.from('disparadores').select('*').eq('activo', true);
    if (!Array.isArray(disps) || disps.length === 0) return { manejado: false, saltarIA: false };

    for (const d of disps) {
      const conds: Cond[] = Array.isArray(d.condiciones) ? d.condiciones : [];
      const palabras = conds.filter(c => c?.tipo === 'palabras' && c?.valor);
      if (palabras.length === 0) continue;
      const coincide = palabras.some(c =>
        norm(c.valor!).split(/[,\n;|]+/).map(k => k.trim()).filter(Boolean).some(kw => t.includes(kw)),
      );
      if (!coincide) continue;

      const accs: Acc[] = Array.isArray(d.acciones) ? d.acciones : [];
      let hizoAlgo = false;
      for (const a of accs) {
        if (a?.tipo !== 'enviar_plantilla' || !a?.plantilla_id) continue;
        const { data: pl } = await supabase
          .from('plantillas').select('tipo, contenido, imagen_url').eq('id', a.plantilla_id).maybeSingle();
        if (!pl) continue;
        const conTexto = pl.tipo !== 'imagen' && pl.contenido;
        const conImagen = pl.tipo !== 'texto' && pl.imagen_url;
        if (conImagen) await sendImageByUrl(from, pl.imagen_url, conTexto ? pl.contenido : undefined);
        else if (conTexto) await sendTextMessage(from, pl.contenido);
        if (conTexto) await registrar(supabase, from, pl.contenido);
        hizoAlgo = true;
      }
      if (hizoAlgo) return { manejado: true, saltarIA: d.enviar_asistente === false };
    }
    return { manejado: false, saltarIA: false };
  } catch { return { manejado: false, saltarIA: false }; }
}

// ── #5: responder desde una FAQ aprobada ────────────────────────────────────
async function faqAprobada(supabase: any, from: string, t: string): Promise<boolean> {
  try {
    const { data: faqs } = await supabase
      .from('faq_bot').select('pregunta, respuesta').eq('estado', 'aprobada').limit(200);
    if (!Array.isArray(faqs) || faqs.length === 0) return false;

    // Coincidencia conservadora: TODAS las palabras clave (≥4 letras) de la
    // pregunta guardada deben estar en el mensaje del cliente. Evita respuestas
    // equivocadas.
    for (const f of faqs) {
      const claves = norm(f.pregunta).split(/\s+/).filter(w => w.length >= 4);
      if (claves.length < 2) continue;
      if (claves.every(w => t.includes(w)) && f.respuesta) {
        await sendTextMessage(from, f.respuesta);
        await registrar(supabase, from, f.respuesta);
        return true;
      }
    }
    return false;
  } catch { return false; }
}

/**
 * Pre-filtro completo. Devuelve:
 *  - manejado: true si una regla envió (o decidió callar) algo.
 *  - saltarIA: true si NO hay que llamar a la IA en este turno.
 * `supabase` debe venir ya scopeado al tenant (como en el webhook). `msg` es el
 * mensaje entrante de WhatsApp (para ver su tipo: sticker, etc.).
 */
export async function preFiltroBot(
  supabase: any,
  from: string,
  texto: string,
  msg?: { type?: string },
): Promise<{ manejado: boolean; saltarIA: boolean }> {
  try {
    const t = norm(texto);

    // #3 — acuses, stickers y despedidas: no gastar IA, dejar el chat ahí.
    if (esIgnorable(texto, msg?.type)) return { manejado: true, saltarIA: true };

    // #6 — primer contacto desde un anuncio → catálogo + precios (sin IA).
    if (await bienvenidaPorAnuncio(supabase, from)) return { manejado: true, saltarIA: true };

    // Disparadores por palabra (regla → plantilla).
    if (t) {
      const rd = await disparadoresPorPalabra(supabase, from, t);
      if (rd.manejado && rd.saltarIA) return rd;
      // #5 — Pregunta frecuente aprobada.
      if (await faqAprobada(supabase, from, t)) return { manejado: true, saltarIA: true };
      if (rd.manejado) return rd; // regla envió algo pero deja seguir a la IA
    }

    return { manejado: false, saltarIA: false };
  } catch {
    return { manejado: false, saltarIA: false };
  }
}
